module.exports = {
  SECRET: "jfew8u4i3qhng09384gurh9308hfuwqgn",
};
